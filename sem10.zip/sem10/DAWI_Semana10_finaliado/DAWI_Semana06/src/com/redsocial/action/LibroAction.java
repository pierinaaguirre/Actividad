package com.redsocial.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.opensymphony.xwork2.ActionSupport;
import com.redsocial.bean.LibroBean;
import com.redsocial.bean.TemaBean;
import com.redsocial.service.LibroService;
import com.redsocial.service.LibroServiceImpl;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.apachecommons.CommonsLog;

@ParentPackage("dawi")
@CommonsLog
public class LibroAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Para la consulta
		private @Getter @Setter List<LibroBean> lstLibro = new ArrayList<LibroBean>();
		private @Getter @Setter String filtro = "";

		// Para el combo
		private @Getter @Setter List<TemaBean> lstTema = new ArrayList<TemaBean>();

		@Action(value = "/cargaTema", results = { @Result(name = "success", type = "json") })
		public String cargaTema() {
			log.info("En carga tema");
			try {
				LibroServiceImpl service = new LibroServiceImpl();
				lstTema = service.listaTema();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return SUCCESS;
		}
	
	@Action(value = "/consultaLibro", results = { @Result(name = "success", location = "/consultaLibro.jsp") })
	public String listar() {
		log.info("En listar libro");
		try {
			LibroService service = new LibroServiceImpl();
			lstLibro = service.listaLibro(filtro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}
}
