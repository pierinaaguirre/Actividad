package com.redsocial.dao;

import com.redsocial.bean.MedicamentoBean;

public interface MedicamentoDAO {

	public abstract int insertaMedicamento(MedicamentoBean obj) throws Exception;
	
}
