package com.redsocial.service;

import com.redsocial.bean.MedicamentoBean;

public interface MedicamentoService {

	public abstract int insertaMedicamento(MedicamentoBean obj) throws Exception;

}
