package com.redsocial.service;

import java.util.List;

import com.redsocial.bean.FiltroLibroBean;
import com.redsocial.bean.LibroBean;
import com.redsocial.bean.TemaBean;

public interface LibroService {
	public List<LibroBean> listaLibro(String filtro) throws Exception;

	public List<TemaBean> listaTema() throws Exception;

	public List<LibroBean> listaLibro(FiltroLibroBean filtro)  throws Exception;
	public List<LibroBean> listaLibroMultiple(FiltroLibroBean filtro)  throws Exception;


}
