package com.redsocial.service;

import java.util.List;

import com.redsocial.bean.FiltroLibroBean;
import com.redsocial.bean.LibroBean;
import com.redsocial.bean.TemaBean;
import com.redsocial.dao.MySqlLibroDAO;

public class LibroServiceImpl implements LibroService{
	MySqlLibroDAO dao=new MySqlLibroDAO();
	@Override
	public List<LibroBean> listaLibro(FiltroLibroBean filtro) throws Exception {
		return dao.listaLibro(filtro);
	}

	@Override
	public List<LibroBean> listaLibroMultiple(FiltroLibroBean filtro) throws Exception {
		return dao.listaLibroMultiple(filtro);
	}

	@Override
	public List<TemaBean> listaTema() throws Exception {
		return dao.listaTema();
	}

	@Override
	public List<LibroBean> listaLibro(String filtro) throws Exception {
		return dao.listaLibro(filtro);
	}

}
