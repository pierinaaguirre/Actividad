package com.redsocial.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoriaBean {

	private int idCategoria;
	private String nombre;
}
