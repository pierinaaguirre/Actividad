package com.redsocial.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConcursoBean {
	private int idConcurso;
	private String nombre;
	private String fechaInicio;
	private String fechaFin;
	private String estado;

}
