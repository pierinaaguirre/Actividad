package com.redsocial.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MedicamentoBean {

	private int idMedicamento;
	private String nombre;
	private double precio;
	private int stock;
	private String laboratorio;
	
}
