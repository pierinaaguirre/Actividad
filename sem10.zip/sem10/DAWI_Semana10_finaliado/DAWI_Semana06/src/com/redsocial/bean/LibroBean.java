package com.redsocial.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LibroBean {
	private int idLibro;
	private String titulo, precio;
	private TemaBean tema;
}
