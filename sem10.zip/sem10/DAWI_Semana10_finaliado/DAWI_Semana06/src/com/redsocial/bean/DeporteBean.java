package com.redsocial.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeporteBean {
	private int idDeporte;
	private String nombre;

}
